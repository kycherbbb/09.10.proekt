<?php
include 'config.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

$user = $_SESSION['user'];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Профиль — Yung Trappa</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<header class="header">
    <div class="nav-wrapper">
        <div class="logo">Yung Trappa</div>
        <div class="burger" id="burger">☰</div>
        <nav class="nav" id="nav">
            <a href="index.html">Главная</a>
            <a href="music.html">Творчество</a>
            <a href="merch.html">Мерч</a>
            <a href="logout.php">Выйти</a>
        </nav>
    </div>
</header>

<main class="containerr"><br><br>
    <h2>Личный кабинет</h2><br>

    <div class="card" style="max-width: 400px; margin: 0 auto; text-align: left;">
        <p><strong>ФИО:</strong> <?php echo htmlspecialchars($user['full_name']); ?></p>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
        <p><strong>Телефон:</strong> <?php echo htmlspecialchars($user['phone']); ?></p>
    </div>

    <br>
    <a href="logout.php" style="color: #2ba52b;">Выйти из аккаунта</a>
</main>

<footer>
    <div class="div-footer">
        <p>© 2026 Yung Trappa Fan Site</p>
    </div>
</footer>

<script src="js/main.js"></script>
</body>
</html>
