Добавьте сюда изображения: hoodie.jpg, tshirt.jpg, longsleeve.jpg, jacket.jpg
