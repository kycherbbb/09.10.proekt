import React, { createContext, useContext, useEffect, useState } from 'react';

const AuthContext = createContext(null);

const USERS_KEY = 'yt_users';
const SESSION_KEY = 'yt_current_user';
const ORDERS_KEY = 'yt_orders';

const readJSON = (key, fallback) => {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
};

const writeJSON = (key, value) => {
  localStorage.setItem(key, JSON.stringify(value));
};

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const email = localStorage.getItem(SESSION_KEY);
    if (!email) return;
    const users = readJSON(USERS_KEY, []);
    const found = users.find((u) => u.email === email);
    if (found) {
      setUser({ name: found.name, email: found.email, phone: found.phone });
    }
  }, []);

  const register = ({ name, email, phone, password }) => {
    const users = readJSON(USERS_KEY, []);
    const normalizedEmail = email.trim().toLowerCase();
    if (users.some((u) => u.email === normalizedEmail)) {
      return { ok: false, error: 'Пользователь с таким email уже зарегистрирован' };
    }
    const newUser = {
      name: name.trim(),
      email: normalizedEmail,
      phone: phone.trim(),
      password: btoa(password),
    };
    users.push(newUser);
    writeJSON(USERS_KEY, users);
    localStorage.setItem(SESSION_KEY, normalizedEmail);
    setUser({ name: newUser.name, email: newUser.email, phone: newUser.phone });
    return { ok: true };
  };

  const login = (email, password) => {
    const users = readJSON(USERS_KEY, []);
    const normalizedEmail = email.trim().toLowerCase();
    const found = users.find((u) => u.email === normalizedEmail);
    if (!found) {
      return { ok: false, error: 'Пользователь с таким email не найден' };
    }
    if (found.password !== btoa(password)) {
      return { ok: false, error: 'Неверный пароль' };
    }
    localStorage.setItem(SESSION_KEY, normalizedEmail);
    setUser({ name: found.name, email: found.email, phone: found.phone });
    return { ok: true };
  };

  const logout = () => {
    localStorage.removeItem(SESSION_KEY);
    setUser(null);
  };

  const addOrder = (order) => {
    const orders = readJSON(ORDERS_KEY, []);
    const newOrder = {
      id: 'YT-' + Date.now().toString().slice(-6),
      date: new Date().toISOString(),
      status: 'Принят',
      ...order,
    };
    orders.unshift(newOrder);
    writeJSON(ORDERS_KEY, orders);
    return newOrder;
  };

  const getMyOrders = (email) => {
    const orders = readJSON(ORDERS_KEY, []);
    return orders.filter((o) => o.email === email);
  };

  const advanceOrder = (id) => {
    const steps = ['Принят', 'Собран', 'Отправлен', 'Доставлен'];
    const orders = readJSON(ORDERS_KEY, []);
    const next = orders.map((o) => {
      if (o.id !== id) return o;
      const i = steps.indexOf(o.status);
      if (i >= 0 && i < steps.length - 1) return { ...o, status: steps[i + 1] };
      return o;
    });
    writeJSON(ORDERS_KEY, next);
    return next.filter((o) => o.email === (user && user.email));
  };

  return (
    <AuthContext.Provider value={{ user, register, login, logout, addOrder, getMyOrders, advanceOrder }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}

export const ORDER_STEPS = ['Принят', 'Собран', 'Отправлен', 'Доставлен'];
