import React from 'react';

export default function Footer() {
    return (
        <footer>
            <div className="div-footer">
                <p>© 2026 Yung Trappa Fan Site</p>
            </div>
        </footer>
    );
}
