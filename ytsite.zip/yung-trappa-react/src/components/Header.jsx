import React, { useState, useEffect } from 'react';
import { NavLink, Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';

export default function Header() {
    const [scrolled, setScrolled] = useState(false);
    const [menuActive, setMenuActive] = useState(false);
    const { user, logout } = useAuth();
    const navigate = useNavigate();

    useEffect(() => {
        const handleScroll = () => {
            if (window.scrollY > 50) {
                setScrolled(true);
            } else {
                setScrolled(false);
            }
        };
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    const closeMenu = () => {
        setMenuActive(false);
    };

    const handleLogout = () => {
        logout();
        closeMenu();
        navigate('/');
    };

    return (
        <header className="header" style={{ background: scrolled ? '#111' : '#000' }}>
            <div className="nav-wrapper">
                <Link to="/" className="logo" onClick={closeMenu}>YungTrappaFanSite</Link>

                <div className="burger" id="burger" onClick={() => setMenuActive(!menuActive)}>
                    ☰
                </div>

                <nav className={`nav ${menuActive ? 'active' : ''}`} id="nav">
                    <NavLink to="/" end onClick={closeMenu}>Главная</NavLink>
                    <NavLink to="/about" onClick={closeMenu}>О нас</NavLink>
                    {user ? (
                        <>
                            <NavLink to="/profile" onClick={closeMenu}>Профиль</NavLink>
                            <NavLink to="/" onClick={handleLogout}>Выйти</NavLink>
                        </>
                    ) : (
                        <NavLink to="/register" onClick={closeMenu}>Вход / Регистрация</NavLink>
                    )}
                </nav>
            </div>
        </header>
    );
}
