import React, { useState } from 'react';
import './About.css';

const tracks = [
  'Каделак (как дела) ft. Yung Gum & Yung Pretty',
  'Давай кинем барыгу ft. Sil-a',
  'Я хороший',
  'MDMA',
  'Так не бывает',
];

export default function About() {
  const [name, setName] = useState('');
  const [question, setQuestion] = useState('');
  const [error, setError] = useState('');
  const [sent, setSent] = useState(false);

  const handleAsk = (e) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Представьтесь, пожалуйста');
      return;
    }
    if (question.trim().length < 5) {
      setError('Вопрос слишком короткий — напишите чуть подробнее');
      return;
    }
    const stored = JSON.parse(localStorage.getItem('yt_questions') || '[]');
    stored.unshift({ name: name.trim(), question: question.trim(), date: new Date().toISOString() });
    localStorage.setItem('yt_questions', JSON.stringify(stored));
    setError('');
    setSent(true);
    setName('');
    setQuestion('');
  };

  return (
    <main className="container about-page">
      <section className="bio">
        <h1>О нас</h1>
        
        <p className="about-sub">
          Здесь коротко собрана информация о проекте.
        </p>
        <br />
        <p>
          Этот фанатский сайт посвященный упокоенному российскому трэп-реперу Yung Trappa. <br />
          При его жизни сущестовала лишь группа в ВК, но теперь есть сайт, <br /> на котором вы можете приобрести себе, своим близким или друзьям любую из позиций, <br /> представленных на нашем сайте. <br /><br />
          Следите за обновлениями в группе ВК, возможно (но не точно) скоро будут пояявлять новые позиции. 
        </p>
      </section>
      <br /><br />
      <section className="about-tracks">
        <h1>Спасибо за заказ!</h1>
        <p className="about-sub">Ниже вы можете отправить вопрос нам на почту и мы ответим на него :)</p>
      </section>
      <br />
      <section className="about-ask">
        <h2 >Задать вопрос</h2>
        {sent ? (
          <div className="ask-success">
            <strong>Вопрос отправлен!</strong>
            <p>Спасибо за обращение, скоро ответим.</p>
            <button type="button" onClick={() => setSent(false)}>Задать ещё один</button>
          </div>
        ) : (
          <form onSubmit={handleAsk} className="ask-form">
            <h3>Ваш вопрос</h3>
            <input
              type="text"
              placeholder="Ваше имя"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className={name.trim() ? 'valid' : ''}
            />
            <textarea
              placeholder="Текст вопроса"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              rows={4}
            />
            {error && <small style={{ color: '#ff6b6b' }}>{error}</small>}
            <button type="submit">Отправить вопрос</button>
          </form>
        )}
      </section>
    </main>
  );
}
