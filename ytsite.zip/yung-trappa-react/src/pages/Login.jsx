import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';

export default function Login() {
    const { login } = useAuth();
    const navigate = useNavigate();
    const [formData, setFormData] = useState({ email: '', password: '' });
    const [authError, setAuthError] = useState('');

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({ ...prev, [name]: value }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (!formData.email.includes('@')) {
            setAuthError('Неверный формат Email');
            return;
        }
        if (!formData.password) {
            setAuthError('Пароль обязателен');
            return;
        }
        const res = login(formData.email, formData.password);
        if (!res.ok) {
            setAuthError(res.error);
            return;
        }
        setAuthError('');
        navigate('/profile');
    };

    return (
        <main className="container">
            <div className="containerr">
                <h2>Авторизация</h2>

                <form onSubmit={handleSubmit}>
                    <h3>Вход в аккаунт</h3>

                    <input
                        type="email"
                        name="email"
                        placeholder="Email"
                        value={formData.email}
                        onChange={handleInputChange}
                        className={formData.email && formData.email.includes('@') ? 'valid' : ''}
                        required
                    />

                    <input
                        type="password"
                        name="password"
                        placeholder="Пароль"
                        value={formData.password}
                        onChange={handleInputChange}
                        className={formData.password.length >= 1 ? 'valid' : ''}
                        required
                    />

                    {authError && <small style={{ color: '#ff6b6b' }}>{authError}</small>}

                    <button type="submit">Войти</button>

                    <div className="auth-toggle">
                        Ещё нет аккаунта? <Link to="/register"><span>Зарегистрироваться</span></Link>
                    </div>
                </form>
            </div>
        </main>
    );
}
