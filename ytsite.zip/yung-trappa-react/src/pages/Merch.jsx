import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import './Merch.css';

const products = [
  {
    id: 'hoodie-black',
    name: 'черное худи "YMB"',
    price: 5000,
    image: '/merch/hoodie-black.jpg',
    description: 'Худи - 80% хлопок , 20% ПЭ. Доступно для заказа!',
    sizes: ['S', 'M', 'L', 'XL'],
  },
  {
    id: 'hoodie-white',
    name: 'белое худи "YMB"',
    price: 5000,
    image: '/merch/hoodie-white.jpg',
    description: 'Худи - 80% хлопок , 20% ПЭ. Доступно для заказа!',
    sizes: ['S', 'M', 'L', 'XL'],
  },
  {
    id: 'tshirt-black',
    name: 'черная футболка "YMB"',
    price: 3000,
    image: '/merch/tshirt-black.jpg',
    description: 'Футболкa - 100% хлопок. Доступно для заказа!',
    sizes: ['S', 'M', 'L', 'XL'],
  },
  {
    id: 'tshirt-white',
    name: 'белая футболка "YMB"',
    price: 3000,
    image: '/merch/tshirt-white.jpg',
    description: 'Футболкa - 100% хлопок. Доступно для заказа',
    sizes: ['S', 'M', 'L', 'XL'],
  },
  {
    id: 'cap-black',
    name: 'футболка "2Stoopied"',
    price: 2790,
    image: '/image/tshirt2st.jpg',
    description: 'Футболкa - 100% хлопок. Доступно для заказа',
    sizes: ['S', 'M', 'L', 'XL'],
  },
  {
    id: 'beanie-trappa',
    name: 'шапка "2Stoopied"',
    price: 2000,
    image: 'image/shapka.jpg',
    description: 'Тёплая с нашивкой. Универсальный размер.',
    sizes: ['One Size'],
  },
  {
    id: 'shopper-ymb',
    name: 'худи "#FreeYungTrappa"',
    price: 6000,
    image: 'image/hoodie2st.jpg',
    description: 'Худи - 80% хлопок , 20% ПЭ. Доступно для заказа! Эксклюзивно в поддержку)',
    sizes: ['S', 'M', 'L', 'XL'],
  },
];

const formatPrice = (n) => Number(n).toLocaleString('ru-RU') + ' ₽';
const needsSize = (p) => p.sizes.length > 0;

function MerchImage({ product }) {
  const [broken, setBroken] = useState(false);
  if (!product.image || broken) {
    return (
      <div className="merch-image-placeholder">
        <span>YMB</span>
        <small>фото скоро</small>
      </div>
    );
  }
  return <img src={product.image} alt={product.name} loading="lazy" onError={() => setBroken(true)} />;
}

export default function Merch() {
  const { user, addOrder } = useAuth();
  const [selectedSizes, setSelectedSizes] = useState({});
  const [sizeError, setSizeError] = useState({});
  const [checkout, setCheckout] = useState(null);
  const [form, setForm] = useState({ name: '', phone: '', address: '', pay: 'card' });
  const [formError, setFormError] = useState('');
  const [done, setDone] = useState(false);
  const [createdOrder, setCreatedOrder] = useState(null);

  const selectSize = (id, size) => {
    setSelectedSizes((prev) => ({ ...prev, [id]: size }));
    setSizeError((prev) => ({ ...prev, [id]: false }));
  };

  const openCheckout = (product) => {
    if (needsSize(product) && !selectedSizes[product.id]) {
      setSizeError((prev) => ({ ...prev, [product.id]: true }));
      return;
    }
    const size = needsSize(product) ? selectedSizes[product.id] : 'Без размера';
    setCheckout({ ...product, size });
    setForm({
      name: user ? user.name : '',
      phone: user ? user.phone : '',
      address: '',
      pay: 'card',
    });
    setFormError('');
    setDone(false);
    setCreatedOrder(null);
  };

  const closeCheckout = () => {
    setCheckout(null);
    setDone(false);
    setFormError('');
    setCreatedOrder(null);
  };

  const handlePay = (e) => {
    e.preventDefault();
    if (!user) {
      setFormError('Чтобы оформить заказ, войдите в аккаунт');
      return;
    }
    if (!form.name.trim()) {
      setFormError('Введите имя');
      return;
    }
    if (form.phone.replace(/\D/g, '').length < 10) {
      setFormError('Введите корректный телефон (минимум 10 цифр)');
      return;
    }
    if (!form.address.trim()) {
      setFormError('Введите адрес доставки');
      return;
    }
    const order = addOrder({
      email: user.email,
      productId: checkout.id,
      productName: checkout.name,
      price: checkout.price,
      size: checkout.size,
      name: form.name.trim(),
      phone: form.phone.trim(),
      address: form.address.trim(),
      pay: form.pay,
    });
    setCreatedOrder(order);
    setFormError('');
    setDone(true);
  };

  return (
    <main className="container merch-page">
      <div className="merch-heading">
        <h1>Мерч</h1>
      </div>

      {!user && (
        <div className="merch-notice">
          Чтобы купить, <Link to="/login" style={{ color: '#3f9b33', fontWeight: 800 }}>войдите</Link>
          {' '}или <Link to="/register" style={{ color: '#3f9b33', fontWeight: 800 }}>зарегистрируйтесь</Link>.
          Без входа кнопка «Купить» попросит авторизацию.
        </div>
      )}

      <div className="merch-grid">
        {products.map((p) => (
          <article key={p.id} className="merch-card">
            <div className="merch-image">
              <MerchImage product={p} />
              <span className="merch-price-badge">{formatPrice(p.price)}</span>
            </div>

            <div className="merch-card-content">
              <h2>{p.name}</h2>
              <p>{p.description}</p>

              {needsSize(p) && (
                <div className="size-block">
                  <span>Размер:</span>
                  <div className="size-list">
                    {p.sizes.map((s) => (
                      <button
                        key={s}
                        type="button"
                        className={selectedSizes[p.id] === s ? 'selected' : ''}
                        onClick={() => selectSize(p.id, s)}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                  {sizeError[p.id] && (
                    <small style={{ color: '#ff6b6b' }}>Сначала выберите размер</small>
                  )}
                </div>
              )}

              <div className="merch-card-footer">
                <strong>{formatPrice(p.price)}</strong>
                <button type="button" className="buy-button" onClick={() => openCheckout(p)}>
                  Купить
                </button>
              </div>
            </div>
          </article>
        ))}
      </div>

      {checkout && (
        <div className="checkout-overlay" onClick={closeCheckout}>
          <div className="checkout-modal" onClick={(e) => e.stopPropagation()}>
            <button type="button" className="checkout-close" onClick={closeCheckout}>×</button>

            {!done ? (
              <>
                <span className="merch-label">ОФОРМЛЕНИЕ ЗАКАЗА</span>
                <h2>{checkout.name}</h2>
                <p className="checkout-summary">
                  Размер: <b>{checkout.size}</b> · {formatPrice(checkout.price)}
                </p>

                {!user ? (
                  <div className="auth-gate">
                    <p>Заказ доступен только после входа. Войдите или создайте аккаунт — это займёт минуту.</p>
                    <div className="profile-actions">
                      <Link to="/login" onClick={closeCheckout}><button type="button">Войти</button></Link>
                      <Link to="/register" onClick={closeCheckout}><button type="button">Регистрация</button></Link>
                    </div>
                    {formError && <small style={{ color: '#ff6b6b' }}>{formError}</small>}
                  </div>
                ) : (
                  <form className="checkout-form" onSubmit={handlePay}>
                    <label>
                      Имя
                      <input
                        type="text"
                        placeholder="Ваше имя"
                        value={form.name}
                        onChange={(e) => setForm({ ...form, name: e.target.value })}
                      />
                    </label>
                    <label>
                      Телефон
                      <input
                        type="tel"
                        placeholder="+7 ___ ___-__-__"
                        value={form.phone}
                        onChange={(e) => setForm({ ...form, phone: e.target.value })}
                      />
                    </label>
                    <label>
                      Адрес доставки
                      <input
                        type="text"
                        placeholder="Город, улица, дом, квартира"
                        value={form.address}
                        onChange={(e) => setForm({ ...form, address: e.target.value })}
                      />
                    </label>
                    <label>
                      Способ оплаты
                      <select
                        value={form.pay}
                        onChange={(e) => setForm({ ...form, pay: e.target.value })}
                        style={{ background: '#242424', color: '#fff', padding: '12px 13px', borderRadius: '5px', border: '1px solid #393939' }}
                      >
                        <option value="card">Картой онлайн</option>
                        <option value="cash">При получении</option>
                      </select>
                    </label>

                    {formError && <small style={{ color: '#ff6b6b' }}>{formError}</small>}

                    <button type="submit" className="pay-button">
                      Оплатить {formatPrice(checkout.price)}
                    </button>
                    <small>Демо-режим: деньги не списываются, заказ только оформляется.</small>
                  </form>
                )}
              </>
            ) : (
              <>
                <span className="merch-label">ЗАКАЗ ПРИНЯТ</span>
                <h2>Спасибо, {form.name}!</h2>
                <p className="checkout-summary">
                  {checkout.name}, размер {checkout.size} — {formatPrice(checkout.price)}.
                  <br />
                  Номер заказа: <b>{createdOrder && createdOrder.id}</b>
                  <br />
                  Оплата: {form.pay === 'card' ? 'картой онлайн' : 'при получении'}.
                  <br />
                  Доставим на: {form.address}
                </p>
                <br />
                <div className="profile-actions">
                  <Link to="/profile" onClick={closeCheckout}><button type="button" className="pay-button">Отследить в профиле</button></Link>
                  <button type="button" className="pay-button" onClick={closeCheckout}>
                    Закрыть
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </main>
  );
}
