import React, { useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ORDER_STEPS, useAuth } from '../auth/AuthContext';
import './Profile.css';

const formatPrice = (n) => Number(n).toLocaleString('ru-RU') + ' ₽';

export default function Profile() {
  const { user, logout, getMyOrders, advanceOrder } = useAuth();
  const navigate = useNavigate();
  const [tick, setTick] = useState(0);

  const orders = useMemo(
    () => (user ? getMyOrders(user.email) : []),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [user, tick]
  );

  if (!user) {
    return (
      <main className="container profile-page">
        <span className="merch-label">ПРОФИЛЬ</span>
        <h1>Вы не вошли</h1>
        <p className="profile-sub">Войдите, чтобы заказывать мерч и отслеживать заказы.</p>
        <div className="profile-actions">
          <Link to="/login"><button type="button">Войти</button></Link>
          <Link to="/register"><button type="button">Регистрация</button></Link>
        </div>
      </main>
    );
  }

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const handleAdvance = (id) => {
    advanceOrder(id);
    setTick((t) => t + 1);
  };

  return (
    <main className="container profile-page">
      <span className="merch-label">ПРОФИЛЬ</span>
      <h1>Личный кабинет</h1>

      <div className="profile-card">
        <div>
          <p><strong>Имя:</strong> {user.name}</p>
          <p><strong>Email:</strong> {user.email}</p>
          <p><strong>Телефон:</strong> {user.phone}</p>
        </div>
        <button type="button" className="logout-button" onClick={handleLogout}>Выйти</button>
      </div>

      <h2>Мои заказы ({orders.length})</h2>
      {orders.length === 0 ? (
        <div className="merch-notice">
          Заказов пока нет. Выберите что-нибудь на главной и нажмите «Купить» — заказ появится здесь.
        </div>
      ) : (
        <div className="orders-list">
          {orders.map((o) => {
            const stepIndex = ORDER_STEPS.indexOf(o.status);
            return (
              <article key={o.id} className="order-card">
                <div className="order-head">
                  <strong>{o.id}</strong>
                  <span className="order-date">
                    {new Date(o.date).toLocaleString('ru-RU')}
                  </span>
                </div>
                <p className="order-title">{o.productName} · размер {o.size}</p>
                <p className="order-meta">
                  {formatPrice(o.price)} · {o.pay === 'card' ? 'картой онлайн' : 'при получении'} · {o.address}
                </p>
                <div className="order-steps">
                  {ORDER_STEPS.map((s, i) => (
                    <div key={s} className={`order-step ${i <= stepIndex ? 'done' : ''}`}>
                      <span className="dot" />
                      <small>{s}</small>
                    </div>
                  ))}
                </div>
                <div className="order-foot">
                  <span className="order-status">Статус: <b>{o.status}</b></span>
                  {stepIndex < ORDER_STEPS.length - 1 && (
                    <button type="button" onClick={() => handleAdvance(o.id)}>
                      Обновить статус (демо)
                    </button>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      )}
    </main>
  );
}
