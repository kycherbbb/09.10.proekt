import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';

export default function Register() {
    const { login, register } = useAuth();
    const navigate = useNavigate();
    const [isLogin, setIsLogin] = useState(false);
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        phone: '',
        password: '',
        confirmPassword: ''
    });

    const [authError, setAuthError] = useState('');

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (isLogin) {
            if (!formData.email.includes('@')) {
                setAuthError('Неверный формат Email');
                return;
            }
            if (!formData.password) {
                setAuthError('Пароль обязателен');
                return;
            }
            const res = login(formData.email, formData.password);
            if (!res.ok) {
                setAuthError(res.error);
                return;
            }
            setAuthError('');
            navigate('/profile');
            return;
        }

        if (!formData.name.trim()) {
            setAuthError('Имя обязательно');
            return;
        }
        if (!formData.email.includes('@')) {
            setAuthError('Неверный формат Email');
            return;
        }
        if (formData.phone.trim().length < 10) {
            setAuthError('Длина телефона должна быть не менее 10 цифр');
            return;
        }
        if (formData.password.length < 6) {
            setAuthError('Пароль должен быть не менее 6 символов');
            return;
        }
        if (formData.password !== formData.confirmPassword) {
            setAuthError('Пароли не совпадают');
            return;
        }
        const res = register({
            name: formData.name,
            email: formData.email,
            phone: formData.phone,
            password: formData.password,
        });
        if (!res.ok) {
            setAuthError(res.error);
            return;
        }
        setAuthError('');
        navigate('/profile');
    };

    const toggleMode = () => {
        setIsLogin(!isLogin);
        setAuthError('');
        setFormData({
            name: '',
            email: '',
            phone: '',
            password: '',
            confirmPassword: ''
        });
    };

    return (
        <main className="container">
            <div className="containerr">
                <h2>{isLogin ? 'Авторизация' : 'Регистрация на сайте'}</h2>

                <form onSubmit={handleSubmit}>
                    <h3>{isLogin ? 'Вход в аккаунт' : 'Создать аккаунт'}</h3>

                    {!isLogin && (
                        <input
                            type="text"
                            name="name"
                            placeholder="ФИО"
                            value={formData.name}
                            onChange={handleInputChange}
                            className={formData.name ? 'valid' : ''}
                            required
                        />
                    )}

                    <input
                        type="email"
                        name="email"
                        placeholder="Email"
                        value={formData.email}
                        onChange={handleInputChange}
                        className={formData.email && formData.email.includes('@') ? 'valid' : ''}
                        required
                    />

                    {!isLogin && (
                        <input
                            type="tel"
                            name="phone"
                            placeholder="Телефон"
                            value={formData.phone}
                            onChange={handleInputChange}
                            className={formData.phone.length >= 10 ? 'valid' : ''}
                            required
                        />
                    )}

                    <input
                        type="password"
                        name="password"
                        placeholder="Пароль"
                        value={formData.password}
                        onChange={handleInputChange}
                        className={formData.password.length >= (isLogin ? 1 : 6) ? 'valid' : ''}
                        required
                    />

                    {!isLogin && (
                        <input
                            type="password"
                            name="confirmPassword"
                            placeholder="Подтвердите пароль"
                            value={formData.confirmPassword}
                            onChange={handleInputChange}
                            className={formData.confirmPassword && formData.confirmPassword === formData.password ? 'valid' : ''}
                            required
                        />
                    )}

                    {authError && <small style={{ color: '#ff6b6b' }}>{authError}</small>}

                    <button type="submit">{isLogin ? 'Войти' : 'Зарегистрироваться'}</button>

                    <div className="auth-toggle">
                        {isLogin ? (
                            <>
                                Ещё нет аккаунта? <span onClick={toggleMode}>Зарегистрироваться</span>
                            </>
                        ) : (
                            <>
                                Уже есть аккаунт? <span onClick={toggleMode}>Войти</span>
                            </>
                        )}
                    </div>
                </form>
            </div>
        </main>
    );
}
