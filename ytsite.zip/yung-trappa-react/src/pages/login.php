<?php
include 'config.php';

$error = '';

if (isset($_POST['login'])) {
    $email    = trim($_POST['email']);
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        $error = 'Все поля обязательны для заполнения';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Некорректный email';
    } else {
        $stmt = $conn->prepare("SELECT id, full_name, email, phone, password FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                $_SESSION['user'] = [
                    'id'        => $user['id'],
                    'full_name' => $user['full_name'],
                    'email'     => $user['email'],
                    'phone'     => $user['phone']
                ];
                header("Location: profile.php");
                exit;
            } else {
                $error = 'Неверный пароль';
            }
        } else {
            $error = 'Пользователь с таким email не найден';
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вход — Yung Trappa</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<header class="header">
    <div class="nav-wrapper">
        <div class="logo">Yung Trappa</div>
        <div class="burger" id="burger">☰</div>
        <nav class="nav" id="nav">
            <a href="index.html">Главная</a>
            <a href="music.html">Творчество</a>
            <a href="merch.html">Мерч</a>
            <a href="register.php">Регистрация</a>
            <a href="login.php">Вход</a>
        </nav>
    </div>
</header>

<main class="containerr"><br><br>
    <h2>Вход</h2><br>

    <?php if ($error): ?>
        <p style="color: #ff4444; margin-bottom: 10px;"><?php echo htmlspecialchars($error); ?></p>
    <?php endif; ?>

    <form method="POST">
        <input type="email" name="email" placeholder="Email" required
               value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
        <input type="password" name="password" placeholder="Пароль" required>
        <button type="submit" name="login">Войти</button>
    </form>

    <p style="margin-top: 15px;">Нет аккаунта? <a href="register.php" style="color: #2ba52b;">Зарегистрироваться</a></p>
</main>

<footer>
    <div class="div-footer">
        <p>© 2026 Yung Trappa Fan Site</p>
    </div>
</footer>

<script src="js/main.js"></script>
</body>
</html>
