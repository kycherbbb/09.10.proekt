<?php
include 'config.php';

$error = '';
$success = '';

if (isset($_POST['register'])) {
    $full_name = trim($_POST['full_name']);
    $email     = trim($_POST['email']);
    $phone     = trim($_POST['phone']);
    $password  = $_POST['password'];
    $password_confirm = $_POST['password_confirm'];

    if (empty($full_name) || empty($email) || empty($phone) || empty($password)) {
        $error = 'Все поля обязательны для заполнения';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Некорректный email';
    } elseif (strlen($phone) < 10) {
        $error = 'Телефон должен содержать не менее 10 символов';
    } elseif (strlen($password) < 6) {
        $error = 'Пароль должен быть не менее 6 символов';
    } elseif ($password !== $password_confirm) {
        $error = 'Пароли не совпадают';
    } else {
    
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $error = 'Пользователь с таким email уже зарегистрирован';
        } else {
   
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (full_name, email, phone, password) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $full_name, $email, $phone, $hashed_password);

            if ($stmt->execute()) {
                $_SESSION['user'] = [
                    'id'        => $stmt->insert_id,
                    'full_name' => $full_name,
                    'email'     => $email,
                    'phone'     => $phone
                ];
                header("Location: profile.php");
                exit;
            } else {
                $error = 'Ошибка при регистрации. Попробуйте позже.';
            }
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация — Yung Trappa</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<header class="header">
    <div class="nav-wrapper">
        <div class="logo">Yung Trappa</div>
        <div class="burger" id="burger">☰</div>
        <nav class="nav" id="nav">
            <a href="index.html">Главная</a>
            <a href="music.html">Творчество</a>
            <a href="merch.html">Мерч</a>
            <a href="register.php">Регистрация</a>
            <a href="login.php">Вход</a>
        </nav>
    </div>
</header>

<main class="containerr"><br><br>
    <h2>Регистрация</h2><br>

    <?php if ($error): ?>
        <p style="color: #ff4444; margin-bottom: 10px;"><?php echo htmlspecialchars($error); ?></p>
    <?php endif; ?>

    <?php if ($success): ?>
        <p style="color: #2ba52b; margin-bottom: 10px;"><?php echo htmlspecialchars($success); ?></p>
    <?php endif; ?>

    <form method="POST">
        <input type="text" name="full_name" placeholder="ФИО" required
               value="<?php echo isset($_POST['full_name']) ? htmlspecialchars($_POST['full_name']) : ''; ?>">
        <input type="email" name="email" placeholder="Email" required
               value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
        <input type="tel" name="phone" placeholder="Телефон" required
               value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>">
        <input type="password" name="password" placeholder="Пароль" required>
        <input type="password" name="password_confirm" placeholder="Подтвердите пароль" required>
        <button type="submit" name="register">Зарегистрироваться</button>
    </form>

    <p style="margin-top: 15px;">Уже есть аккаунт? <a href="login.php" style="color: #2ba52b;">Войти</a></p>
</main>

<footer>
    <div class="div-footer">
        <p>© 2026 Yung Trappa Fan Site</p>
    </div>
</footer>

<script src="js/main.js"></script>
</body>
</html>
