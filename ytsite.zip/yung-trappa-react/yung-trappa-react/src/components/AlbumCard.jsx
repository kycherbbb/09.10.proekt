import { useState } from 'react'
import './AlbumCard.css'

function AlbumCard({ title }) {
  const [clicked, setClicked] = useState(false)

  const handleClick = () => {
    setClicked(true)
    alert(`Ты выбрал альбом: ${title}`)
  }

  return (
    <div
      className={`album-card${clicked ? ' album-card--clicked' : ''}`}
      onClick={handleClick}
    >
      {title}
    </div>
  )
}

export default AlbumCard
