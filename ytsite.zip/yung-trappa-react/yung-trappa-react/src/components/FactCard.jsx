import { useState } from 'react'
import './FactCard.css'

function FactCard({ children }) {
  const [selected, setSelected] = useState(false)

  const handleClick = () => {
    setSelected(true)
    alert('Факт выбран')
  }

  return (
    <div
      className={`fact-card${selected ? ' fact-card--selected' : ''}`}
      onClick={handleClick}
    >
      {children}
    </div>
  )
}

export default FactCard
