import { useState } from 'react'
import './MerchForm.css'

function MerchForm() {
  const [form, setForm] = useState({
    fio: '',
    email: '',
    phone: '',
    date: '',
    size: ''
  })
  const [touched, setTouched] = useState({})

  const handleChange = (e) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }))
    setTouched(prev => ({ ...prev, [e.target.name]: true }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()

    if (!form.email.includes('@')) {
      alert('Ошибка email')
      return
    }
    if (form.phone.replace(/\D/g, '').length < 10) {
      alert('Ошибка телефона')
      return
    }

    alert('Заказ оформлен')
    setForm({ fio: '', email: '', phone: '', date: '', size: '' })
    setTouched({})
  }

  const borderStyle = (name) =>
    touched[name] && form[name]
      ? '2px solid #2ba52b'
      : '2px solid transparent'

  return (
    <form className="merch-form" onSubmit={handleSubmit}>
      <input
        type="text"
        name="fio"
        placeholder="ФИО"
        value={form.fio}
        onChange={handleChange}
        required
        style={{ border: borderStyle('fio') }}
      />
      <input
        type="email"
        name="email"
        placeholder="Email"
        value={form.email}
        onChange={handleChange}
        required
        style={{ border: borderStyle('email') }}
      />
      <input
        type="tel"
        name="phone"
        placeholder="Телефон"
        value={form.phone}
        onChange={handleChange}
        required
        style={{ border: borderStyle('phone') }}
      />
      <input
        type="date"
        name="date"
        value={form.date}
        onChange={handleChange}
        required
        style={{ border: borderStyle('date') }}
      />
      <select
        name="size"
        value={form.size}
        onChange={handleChange}
        required
        style={{ border: borderStyle('size') }}
      >
        <option value="">Размер</option>
        <option value="S">S</option>
        <option value="M">M</option>
        <option value="L">L</option>
      </select>
      <button type="submit">Купить</button>
    </form>
  )
}

export default MerchForm
