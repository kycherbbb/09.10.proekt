import React, { useState } from 'react';
import './About.css';

const tracks = [
  'Каделак (как дела) ft. Yung Gum & Yung Pretty',
  'Давай кинем барыгу ft. Sil-a',
  'Я хороший',
  'MDMA',
  'Так не бывает',
];

export default function About() {
  const [name, setName] = useState('');
  const [question, setQuestion] = useState('');
  const [error, setError] = useState('');
  const [sent, setSent] = useState(false);

  const handleAsk = (e) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Представьтесь, пожалуйста');
      return;
    }
    if (question.trim().length < 5) {
      setError('Вопрос слишком короткий — напишите чуть подробнее');
      return;
    }
    const stored = JSON.parse(localStorage.getItem('yt_questions') || '[]');
    stored.unshift({ name: name.trim(), question: question.trim(), date: new Date().toISOString() });
    localStorage.setItem('yt_questions', JSON.stringify(stored));
    setError('');
    setSent(true);
    setName('');
    setQuestion('');
  };

  return (
    <main className="container about-page">
      <section className="bio">
        <span className="merch-label">О НАС</span>
        <h1>О нас</h1>
        <p>
          Это фанатский сайт Yung Trappa (настоящее имя — Владислав Олегович Ширяев) —
          российского рэпера, автора-исполнителя в жанрах хип-хоп и трэп.
          Родился 14 августа 1995 года в Санкт-Петербурге, умер 2 февраля 2023 года.
          Считался новатором, одним из первопроходцев трэпа в России и основоположником
          популяризации этого жанра в русском рэпе. Основатель творческого объединения
          и независимого лейбла Yung Mafia Business.
        </p>
        <p className="about-sub">
          Здесь мы собираем биографию, творчество и официальный мерч:
          главная страница — магазин, а эта — коротко о проекте и артисте.
        </p>
      </section>

      <section className="about-tracks">
        <h2>Популярные треки</h2>
        <ul className="tracks">
          {tracks.map((track, i) => (
            <li key={i}>{track}</li>
          ))}
        </ul>
      </section>

      <section className="about-ask">
        <h2>Задать вопрос</h2>
        <p className="about-sub">Спросите о сайте, заказах или творчестве — ответим на почту или в соцсетях.</p>
        {sent ? (
          <div className="ask-success">
            <strong>Вопрос отправлен!</strong>
            <p>Спасибо за обращение, скоро ответим.</p>
            <button type="button" onClick={() => setSent(false)}>Задать ещё один</button>
          </div>
        ) : (
          <form onSubmit={handleAsk} className="ask-form">
            <h3>Ваш вопрос</h3>
            <input
              type="text"
              placeholder="Ваше имя"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className={name.trim() ? 'valid' : ''}
            />
            <textarea
              placeholder="Текст вопроса"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              rows={4}
            />
            {error && <small style={{ color: '#ff6b6b' }}>{error}</small>}
            <button type="submit">Отправить вопрос</button>
          </form>
        )}
      </section>
    </main>
  );
}
